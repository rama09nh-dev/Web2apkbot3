import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';

/// App-wide decorative background video. It is intentionally muted and
/// rendered as a subtle overlay so existing page layouts and media remain.
class GlobalBackgroundVideo extends StatefulWidget {
  final Widget child;

  const GlobalBackgroundVideo({super.key, required this.child});

  @override
  State<GlobalBackgroundVideo> createState() => _GlobalBackgroundVideoState();
}

class _GlobalBackgroundVideoState extends State<GlobalBackgroundVideo>
    with WidgetsBindingObserver {
  late final VideoPlayerController _controller;
  bool _ready = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _controller = VideoPlayerController.asset(
      'assets/videos/NoxvexCore_global_background.mp4',
    );
    _initialize();
  }

  Future<void> _initialize() async {
    try {
      await _controller.initialize();
      await _controller.setVolume(0);
      await _controller.setLooping(true);
      if (!mounted) return;
      setState(() => _ready = true);
      await _controller.play();
    } catch (_) {
      // Keep the app fully usable if the optional background video cannot load.
    }
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (!_ready) return;
    if (state == AppLifecycleState.resumed) {
      _controller.play();
    } else if (state == AppLifecycleState.paused ||
        state == AppLifecycleState.inactive ||
        state == AppLifecycleState.detached) {
      _controller.pause();
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      fit: StackFit.expand,
      children: [
        widget.child,
        if (_ready)
          Positioned.fill(
            child: IgnorePointer(
              child: Opacity(
                // Low opacity keeps text, buttons, and cards easy to read.
                opacity: 0.19,
                child: FittedBox(
                  fit: BoxFit.cover,
                  child: SizedBox(
                    width: _controller.value.size.width,
                    height: _controller.value.size.height,
                    child: VideoPlayer(_controller),
                  ),
                ),
              ),
            ),
          ),
      ],
    );
  }
}
